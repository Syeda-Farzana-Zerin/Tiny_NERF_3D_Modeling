import torch
import numpy as np
from PIL import Image
from pytorch3d.io import load_objs_as_meshes
from pytorch3d.renderer import (
    look_at_view_transform,
    FoVPerspectiveCameras,
    PointLights,
    RasterizationSettings,
    MeshRenderer,
    MeshRasterizer,
    SoftPhongShader,
)

# Set the device (GPU if available, else CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the mesh from the obj file
obj_file = "DeskOBJ.obj"
mesh = load_objs_as_meshes([obj_file], device=device)

# Set parameters for rendering
dist = 5  # Distance of the camera from the object
elev = 15  # Elevation angle
image_size = 100  # Target size for output images
num_angles = 106  # Number of views to render
focal = 138.88  # Focal length (example value)

# Set up the renderer
raster_settings = RasterizationSettings(image_size=512, blur_radius=0.0, faces_per_pixel=1)
lights = PointLights(device=device, location=[[0.0, 0.0, 3.0]])

# Initialize arrays to store images, poses, and focal length
images = np.zeros((num_angles, image_size, image_size, 3), dtype=np.float32)
poses = np.zeros((num_angles, 4, 4), dtype=np.float32)

# Loop over each angle, render the image, and store data
for i, azim in enumerate(np.linspace(0, 360, num_angles)):
    # Set the camera for the current angle
    R, T = look_at_view_transform(dist=dist, elev=elev, azim=azim)
    cameras = FoVPerspectiveCameras(device=device, R=R, T=T)
    
    # Initialize the renderer with the current camera
    renderer = MeshRenderer(
        rasterizer=MeshRasterizer(cameras=cameras, raster_settings=raster_settings),
        shader=SoftPhongShader(device=device, cameras=cameras, lights=lights)
    )
    
    # Render the image
    image = renderer(mesh, cameras=cameras, lights=lights)
    image = image[0, ..., :3].cpu().numpy()  # Extract RGB channels

    # Resize to the desired image size (100x100)
    image_resized = np.array(Image.fromarray((image * 255).astype(np.uint8)).resize((image_size, image_size))) / 255.0
    images[i] = image_resized.astype(np.float32)
    
    # Store the pose matrix as a 4x4 matrix (homogeneous coordinates)
    pose = np.eye(4, dtype=np.float32)
    pose[:3, :3] = R.cpu().numpy()
    pose[:3, 3] = T.cpu().numpy().squeeze()
    poses[i] = pose

# Save images, poses, and focal length to an .npz file
np.savez("data.npz", images=images, poses=poses, focal=np.array(focal, dtype=np.float32))

print("Data saved to 'data.npz'")
