import torch
import os
import numpy as np
import matplotlib.pyplot as plt
from pytorch3d.io import load_objs_as_meshes
from pytorch3d.renderer import (
    look_at_view_transform,
    FoVPerspectiveCameras,
    PointLights,
    RasterizationSettings,
    MeshRenderer,
    MeshRasterizer,
    SoftPhongShader,
)
from pytorch3d.structures import Meshes

# Set the device (GPU if available, else CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the mesh from the obj file
obj_file = "DeskOBJ.obj"
mesh = load_objs_as_meshes([obj_file], device=device)

# Set up the renderer
R, T = look_at_view_transform(dist=5, elev=15, azim=0)
cameras = FoVPerspectiveCameras(device=device, R=R, T=T)
lights = PointLights(device=device, location=[[0.0, 0.0, 3.0]])
raster_settings = RasterizationSettings(image_size=512, blur_radius=0.0, faces_per_pixel=1)
renderer = MeshRenderer(
    rasterizer=MeshRasterizer(cameras=cameras, raster_settings=raster_settings),
    shader=SoftPhongShader(device=device, cameras=cameras, lights=lights)
)

# Directory to save rendered images
output_dir = "rendered_images"
os.makedirs(output_dir, exist_ok=True)

# Render and save images from different angles
for i, azim in enumerate(np.linspace(0, 360, 106)):
    R, T = look_at_view_transform(dist=5, elev=15, azim=azim)
    cameras = FoVPerspectiveCameras(device=device, R=R, T=T)
    image = renderer(mesh, cameras=cameras, lights=lights)
    image = image[0, ..., :3].cpu().numpy()

    # Save image using matplotlib
    plt.imsave(f"{output_dir}/image_{i:03d}.png", image)

print("Rendering completed. Images are saved in the 'rendered_images' directory.")
